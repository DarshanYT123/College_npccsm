import './App.css';
import Home from "./Components/Homepage/Home";
import Footer from "./Components/Footer/Footer";
import Navbar1 from './Components/Navbar/Navbar1';

function App() {
  return (
    <div className="App">
    <Navbar1/>
    <Home/>
    <Footer/>
 
    </div>
  );
}

export default App;
