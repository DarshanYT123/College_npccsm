import React from 'react'

const Navbar1 = () => {
  return (
    <>
    <div className="flex items-center justify-center pt-5">

        <h1 className="text-[18px] not-italic font-bold leading-normal text-[#B42120]">કર ભલા હોગા ભલા. </h1>

    </div>

            {/*===================main hedear ==========*/}

            <div className='flex justify-between '>

                <a href="" class="flex items-center p-5">

                    <img src="./img/logo.jpg"  className='w-[100px] h-[100px]' alt="logo"/>

                    <div className='pb-5 ml-5'>
                        <h4 className=''>Sarva Vidyalaya Kelavani Mandal’s</h4>
                    </div>

                </a>




            </div>
    </>
  )
}

export default Navbar1