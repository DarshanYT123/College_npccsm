import React from "react";
import Choosecard from "./Choosecard";
import Galleryswiper from "./Galleryswiper";
import StudentReviiews from './StudentReviiews';
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';

const Home = () => {

  return (
    <div>
        <div className="flex flex-row space-x-10 px-20 justify-center items-center ">
<div className="flex flex-col  px-2 py-20 ">
    <div>
    <h2 className=" text-red-500 font-semibold text-[30px] ">Narsinhbhai Patel College</h2>
    </div>
    <div className="flex flex-row">
    <h2 className="  text-yellow-300 font-semibold text-[15px]">of Computer Studies and Management</h2>
    <h2 className="text-black font-semibold text-[15px] px-1.5 "> -A Constituent College of KSV</h2>
    </div>
    <div className="" >
    <p className="text-[13px] py-3 text-justify ">NPCCSM is constituent college of the University, Kadi Sarvavishwavidyalay, Gandhinagar. It imparts education in computer and management and offers two Programmes BCA and BBA.The University is unique in its own kind and takes credit of being the only one in Gujarat that has contributed towards creating the opportunity of studying in higher education available to the unexplored semi-urban area of North Gujarat.</p>
    </div>
</div>
<div
          className="px-2 py-10 scroll-smooth overflow-x-auto   flex flex-row  "
        >
          <Swiper
            spaceBetween={10}
            slidesPerView={1}
            centeredSlides={false}
            loop={true}
            autoplay={{
              delay: 2500,
              disableOnInteraction: false,
            }}
            pagination={{ el: ".swiper-pagination", clickable: true }}

            // pagination={{
            //     el: '.swiper-pagination',
            //   },
            
            //   // Navigation arrows
            //   navigation={
            //     nextEl: '.swiper-button-next',
            //     prevEl: '.swiper-button-prev',
            //   },
            
            //   // And if we need scrollbar
            //   scrollbar={
            //     el: '.swiper-scrollbar',
            //   }}
          >
              <SwiperSlide>
<img src="./img/R1.png" className="w-[90%]" alt="" />
              </SwiperSlide>
              <SwiperSlide>
              <img src="./img/R1.png" className="w-[90%] " alt="" />
              </SwiperSlide>
              <SwiperSlide>
              <img src="./img/R1.png" className="w-[90%]" alt="" />
              </SwiperSlide>
              <SwiperSlide>
              <img src="./img/R1.png" className="w-[90%]" alt=""/>
              </SwiperSlide>
          </Swiper>
        </div>
        </div>


        <Choosecard/>
        <div className="ml-10 py-5">
      <h1 className="text-[#FF6347] text-[20px] ">Gallery</h1>
    </div>

        <Galleryswiper/>
        <StudentReviiews/> 
    </div>
  );
};

export default Home;
