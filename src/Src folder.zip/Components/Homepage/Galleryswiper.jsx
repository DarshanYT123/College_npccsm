import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { BiChevronLeftCircle, BiChevronRightCircle } from "react-icons/bi";
// Import Swiper styles
import "swiper/css";
import "swiper/css/effect-coverflow";
import "swiper/css/pagination";
import "swiper/css/navigation";

import { EffectCoverflow, Pagination, Navigation } from "swiper/modules";

const Galleryswiper = () => {
  return (
    <div className=" bg-[#ccb5b5] py-10 px-10 ">
      <Swiper
        // breakpoints={{
        //   0: {
        //     slidesPerView: 1,
        //   },
        //   400: {
        //     slidesPerView: 1,
        //   },
        //   639: {
        //     slidesPerView: 2,
        //   },
        //   865: {
        //     slidesPerView: 2,
        //   },
        //   1000: {
        //     slidesPerView: 4,
        //   },
        // }}
        spaceBetween={30}
        slidesPerView={3}
        centeredSlides={true}
        loop={true}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        Navigation={{
          nextEl: ".swiper-button-next1",
          prevEl: ".swiper-button-prev1",
          clickable: true,
        }}
        modules={[EffectCoverflow, Pagination, Navigation]}
        pagination={{ el: ".swiper-pagination", clickable: true }}
        effect={"coverflow"}
        grabCursor={true}
        coverflowEffect={{
          rotate: 0,
          stretch: 0,
          depth: 100,
          modifier: 2.5,
        }}
        className="swiper_container"
        // pagination={{
        //     el: '.swiper-pagination',
        //   },

        //   // Navigation arrows
        //   navigation={
        //     nextEl: '.swiper-button-next',
        //     prevEl: '.swiper-button-prev',
        //   },

        //   // And if we need scrollbar
        //   scrollbar={
        //     el: '.swiper-scrollbar',
        //   }}
      >
        <SwiperSlide>
          <img src="./img/R1.png" className="  " alt="card image" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="./img/R1.png" className="" alt="card image" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="./img/R1.png" className="" alt="card image" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="./img/R1.png" className="" alt="card image" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="./img/R1.png" className="" alt="card image" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="./img/R1.png" className="" alt="card image" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="./img/R1.png" className="" alt="card image" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="./img/R1.png" className="" alt="card image" />
        </SwiperSlide>
        <div className="slider-controler">
          <div className="swiper-button-prev slider-arrow">
            <BiChevronLeftCircle name="arrow-back-outline"></BiChevronLeftCircle>
          </div>
          <div className="swiper-button-next slider-arrow">
            <BiChevronRightCircle name="arrow-forward-outline"></BiChevronRightCircle>
          </div>
          <div className="swiper-pagination"></div>
        </div>
      </Swiper>
    </div>
  );
};

export default Galleryswiper;
