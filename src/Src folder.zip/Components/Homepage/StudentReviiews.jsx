import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "../../index.css";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

// import required modules
import { Autoplay } from "swiper/modules";
const StudentReviiews = () => {
  const WhyData = [
    {
      img: `/img/R1.png`,
      title: `Rakesh Singh`,
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam gravida ultricies purus, et convallis orci. Nam bibendum quam nec dignissim sodales. Vivamus sollicitudin imperdiet vehicula. Proin convallis dui at velit auctor`,
    },
    {
      img: `/img/R1.png`,
      title: `Rakesh Singh`,
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam gravida ultricies purus, et convallis orci. Nam bibendum quam nec dignissim sodales. Vivamus sollicitudin imperdiet vehicula. Proin convallis dui at velit auctor`,
    },

    {
      img: `/img/R1.png`,
      title: `Rakesh Singh`,
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam gravida ultricies purus, et convallis orci. Nam bibendum quam nec dignissim sodales. Vivamus sollicitudin imperdiet vehicula. Proin convallis dui at velit auctor`,
    },
    {
      img: `/img/R1.png`,
      title: `Rakesh Singh`,
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam gravida ultricies purus, et convallis orci. Nam bibendum quam nec dignissim sodales. Vivamus sollicitudin imperdiet vehicula. Proin convallis dui at velit auctor`,
    },
  ];
  return (
    <>
      <div className="ml-10 py-5">
        <h1 className="text-[#B42120] text-[32px] font-bold leading-[46.34px]">Student Reviews</h1>
      </div>

      <div className="px-10 md:px-10 py-10 bg-[#B42120] flex items-center justify-center">
        <Swiper
          // breakpoints={{
          //   0: {
          //     slidesPerView: 1,
          //   },
          //   400: {
          //     slidesPerView: 1,
          //   },
          //   639: {
          //     slidesPerView: 2,
          //   },
          //   865: { 
          //     slidesPerView: 2,
          //   },
          //   1000: {
          //     slidesPerView: 3,
          //   },
          // }}
          slidesPerView={window.innerWidth > 1024 ? 3 : window.innerWidth > 640 ? 2 : 1}
          spaceBetween={30}
          autoplay={{
            delay: 2500,
            disableOnInteraction: false,
          }}
                  loop={true}

          pagination={{
            clickable: true,
          }}
          navigation={true}
          modules={[Autoplay]}
          className="mySwiper"
        >
          <div className="pt-5 pb-5 px-10  flex items-center justify-center">
            {WhyData.map((data, index) => {
              return (
                <SwiperSlide>
                  <div class="flex flex-row items-center     w-[380px] max-h-[224px] min-h-[224px] md:max-h-[224px] md:min-h-[224px] bg-white  border border-grey">
                    <img
                      class="object-cover px-2 w-[200px]   h-[190px] "
                      src={data.img}
                      alt=""
                    />
                    <div class="flex flex-col justify-between p-4 leading-normal">
                      <h5 class="mb-5 text-[#B42120] text-[24px] font-semibold leading-[29.05px] ">
                        {data.title}
                      </h5>
                      <p class="  text-[11px] text-[#6B6B6B] font-medium leading-[14.25px] text-justify  ">
                        {data.description}
                      </p>
                    </div>
                  </div>
                </SwiperSlide>
              );
            })}
          </div>
        </Swiper>
      </div>
    </>
  );
};

export default StudentReviiews;
