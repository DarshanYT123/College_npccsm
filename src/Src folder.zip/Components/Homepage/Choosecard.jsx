import React from 'react'
import { Swiper, SwiperSlide } from 'swiper/react';
import '../../index.css'

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';


// import required modules
import { Autoplay } from 'swiper/modules';





 const Choosecard = () => {
    const WhyData = [
		{
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
		},
		{
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},

        {
          img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
        {
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
        {
          img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
        {
          img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},

    {
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
    {
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
    {
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
    {
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
    {
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
    {
			img:`/img/R1.png`,
			title:`Admission Through Acpc procedure (N
                o management /NRI Quota)`,
			description:`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque at magna non dui volutpat porta.`,
			
			
		},
		
		
		
	];


  return (

    <>

    <div className="ml-10 py-5">
      <h1 className="text-[#B42120] text-[32px] font-bold leading-[46.34px] ">Why Choose NPCCSM</h1>
    </div>

<div className='px-10 md:px-10 py-10 bg-[#B42120] flex items-center justify-center'>
    <Swiper
//  breakpoints={{
//   0: {
//     slidesPerView: 1,
//   },
//   400: {
//     slidesPerView: 1,
//   },
//   639: {
//     slidesPerView: 2,
//   },
//   865: {
//     slidesPerView: 2,
//   },
//   1000: {
//     slidesPerView: 4,
//   },
// }}
       
        spaceBetween={30}
        slidesPerView={window.innerWidth > 1024 ? 4 : window.innerWidth > 820 ? 3 : window.innerWidth > 640 ? 2  : window.innerWidth > 640 ? 1 :1 }
        centeredSlides={true}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        pagination={{
          clickable: true,
        }}
        navigation={true}
        modules={[Autoplay ]}
        className="mySwiper"
      >
        
        
     



    <div className="pt-5 pb-5 px-10  flex items-center justify-center">

   
    {WhyData.map((data, index) => {

        
						return(

                            <SwiperSlide >
                                
                               
                                <div  className=' w-[300px] max-h-[370px] min-h-[370px] md:max-h-[370px] md:min-h-[370px] bg-white rounded-[10px] border shadow-[#898989] '>

                            <div className="p-5">
                                <img src={data.img} className='object-cover w-[30%]' alt="card image"/>
                            </div>
            
                        <div className="px-3">
                            <h3 className="pb-5 text-[24px] text-[#B42120] font-semibold leading-[32.5px]"> {data.title} </h3>
                        </div>
                            <div className="px-3 pt-4 text-justify">
                            <p className="text-[14px] font-normal  leading-[19px] traking-[-2.5%] text-[#898989]">{data.description}</p>
                            </div>
                       
                    </div>
                   

                    </SwiperSlide>

                            );
                        })}


                               


                       
   



   
    
    </div>

    </Swiper>
    
    </div>
    </>
  )
}

export default Choosecard
