import React from "react";


const Footer = () => {

  return (
<div>
<div className="py-5 bg-[#bf4848]">
    <h2 className="text-center font-semibold text-[#fff]  ">"DO GOOD : FOR GOOD WILL COME BACK TO YOU"</h2>
</div>
<div className="flex flex-row justify-center py-10 gap-x-40 px-20 ">
    <div className="flex flex-col gap-y-7">
        <h2 className="text-[#bf4848] text-[25px] font-semibold  ">Reach us</h2>
        <p className="text-justify text-[20px] ">NPCCSM ,Sarva Vidhyalaya Campus Bh.Railway Station,North Gujarat (India),Kadi - 382 715. TeleFax : 02764 -24381</p>
    </div>
    <div className="flex flex-col gap-y-7 ">
        <div>
    <h2 className="text-[#bf4848] text-[25px] font-semibold ">Contact us</h2>
        </div>
    <div className="flex flex-row gap-y-4 gap-x-5 ">
        <div className="flex flex-col  ">
            <div>
        <h2 className="text-[#f9ad4b]  text-[18px] font-semibold ">For BBA</h2>
                
        </div>
<div className="  ">
    <h2 className="py-1">9427679746</h2>
    <h2 className="py-1">9898136371</h2>
</div>
        </div>
        <div className="flex flex-col">
            <div>
        <h2 className="text-[#f9ad4b]  text-[18px] font-semibold ">For BCA</h2>
                
        </div>
<div>
    <h2>9429459700</h2>
    <h2>8849135125</h2>
</div>
        </div>

        </div>    
    </div>
    <div  className="w-[50%]">
        <img src="./img/R1.png" className=""/>
    </div>
</div>
</div>  
  );
};

export default Footer;
